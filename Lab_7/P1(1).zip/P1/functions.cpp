//Define your two functions here using the same input parameters as given in the
//problem statement

//area_and_circ


//contains a negative radii