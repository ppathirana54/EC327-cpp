//put your 2 function prototypes here. They can be found in the problem statement.

