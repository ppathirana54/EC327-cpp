//proper includes go here

//Write the Person Constructor here. See Person.h for input arguments
//be sure to initialize buddy and enemy as NULL in the constructor


//write the calc_takehome_pay function here. 


//write the enemy_or_buddy function here. See problem statement for proper arguments


//write the print_status function here
