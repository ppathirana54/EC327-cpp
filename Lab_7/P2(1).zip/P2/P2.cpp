#include "Person.h"
#include <iostream>
using namespace std;

int main(){
	//used for testing your code. Create 2 people, print their take home pays, 
	//determine if they are enemys or friends using the enemy_or_buddy function
	//then call their print_status() functions.

}